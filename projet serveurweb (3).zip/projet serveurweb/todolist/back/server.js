const express = require('express') /*initialise le serv json */
const mysql = require("mysql") /*initialise le serv sql */
const cors = require("cors")
const app = express()

app.use(cors())
app.use(express.json()) /* permet d'utiliser express et de se co au serv */
const connect=mysql.createConnection({
    host:"127.0.0.1",
    user:"root",
    password:"password",
    port :"3307",
    database:"todolist"
})

connect.connect()
app.get('/', (req, res)=>{
    connect.query('SELECT * FROM todolist;', (err, result)=>{
        if (err) return res.send(err)
        return res.json(result)
    })
})

app.post('/add', (req, res)=>{
    connect.query("INSERT INTO todolist (todo) VALUES ('"+req.body.todo+"');", (err, result)=>{
        if(err) return res.send(err)
        return res.json(result)
    })
})

app.delete('/delete/:id', (req, res)=>{
    connect.query("DELETE FROM todolist WHERE id = "+req.params.id+";", (err, result)=>{
        if(err) return res.send(err)
        return res.json(result)
    })
})


app.listen(4000)