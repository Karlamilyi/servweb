document.addEventListener('DOMContentLoaded', function () {
    const taskForm = document.getElementById('taskForm');
    const textInput = document.getElementById('textInput');
    const addButton = document.getElementById('addButton');
    const deleteButton = document.getElementById('deleteButton');
    const todoList = document.querySelector('.todo');

    let selectedTaskId = null;

    function loadTasks() {
        todoList.innerHTML = '';

        fetch('/')
            .then(response => response.json())
            .then(data => {
                data.forEach(task => {
                    const listItem = document.createElement('li');
                    listItem.textContent = task.todo;

                    const deleteButton = document.createElement('button');
                    deleteButton.textContent = 'Supprimer';
                    deleteButton.addEventListener('click', function () {
                        deleteTask(task.id);
                    });

                    listItem.appendChild(deleteButton);

                    todoList.appendChild(listItem);
                });
            })
            .catch(error => console.error('Erreur lors du chargement des tâches:', error));
    }

    function addTask() {
        const todoText = textInput.value.trim();
        if (todoText !== '') {
            fetch('/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ todo: todoText }),
            })
                .then(response => response.json())
                .then(data => {
                    loadTasks();
                    textInput.value = '';
                })
                .catch(error => console.error('Erreur lors de l\'ajout de la tâche:', error));
        }
    }

    function deleteTask(taskId) {
        if (taskId !== null) {
            fetch('/delete/' + taskId, {
                method: 'DELETE',
            })
                .then(response => response.json())
                .then(data => {
                    loadTasks();
                    selectedTaskId = null;
                })
                .catch(error => console.error('Erreur lors de la suppression de la tâche:', error));
        }
    }

    taskForm.addEventListener('submit', function (event) {
        event.preventDefault();
        addTask();
    });

    loadTasks();

    addButton.addEventListener('click', addTask);

    deleteButton.addEventListener('click', function () {
        deleteTask(selectedTaskId);
    });

});